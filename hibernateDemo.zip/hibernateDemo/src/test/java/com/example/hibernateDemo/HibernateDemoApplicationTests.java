package com.example.hibernateDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HibernateDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
